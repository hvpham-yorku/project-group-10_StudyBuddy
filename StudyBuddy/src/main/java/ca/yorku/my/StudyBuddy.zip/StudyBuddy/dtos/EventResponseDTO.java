package ca.yorku.my.StudyBuddy.dtos;
import java.util.List;

import ca.yorku.my.StudyBuddy.classes.Review;

// These fields are required from the frontend.
// None of this information is confidential except maybe
// participants. If someone bans a person, then we need to send a warning
// that a banned user is joining this session as well.
public record EventResponseDTO(
	String id,
	String title,
	String course,
	HostDTO host,
	String location,
	String date,
	String time,
	int duration,
	String description,
	int maxParticipants,
	List<String> attendees,
	List<String> tags,
	String status,
	List<Review> reviews
) {}